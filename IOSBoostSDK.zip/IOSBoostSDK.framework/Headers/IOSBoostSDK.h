//
//  IOSBoostSDK.h
//  IOSBoostSDK
//
//  Created by A2341 on 04/10/2019.
//  Copyright © 2019 Boost. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IOSBoostSDK.
FOUNDATION_EXPORT double IOSBoostSDKVersionNumber;

//! Project version string for IOSBoostSDK.
FOUNDATION_EXPORT const unsigned char IOSBoostSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IOSBoostSDK/PublicHeader.h>


